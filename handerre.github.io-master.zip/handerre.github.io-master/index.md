
<html lang="no">
<head>
    <meta name="author" content="#">
    <meta charset="UTF-8">

<!-- Koblingen til .css filen (stilarket) mitt -->
<link href="minstil.css" rel="stylesheet" type="text/css">
<meta name="viewport" content="width=device-width, initial-scale=1">


</head>




    
    
        
        <h1> <a href="https://handerre.github.io/Nettside_Prosjektet.html">Her finner du oppgaven om nettside </a></h1>
        
<h1> <a href="https://handerre.github.io/Test/index.html">Test </a></h1>
        

    <div class="footer">
        <p>Copyright &copy; 2020 Bent, Karin og Frode - Sist oppdatert
            <script>
              document.write(Date());
              </script>


